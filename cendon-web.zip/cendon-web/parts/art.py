# -*- coding: utf-8 -*-
"""ภาพประกอบทั้งหมดของเว็บ — เขียนเป็น SVG ล้วน ไม่มีรูปบิตแมป
เส้นทุกเส้นใช้ currentColor หรือตัวแปรสีจาก CSS จึงเปลี่ยนธีมได้ทีเดียว
คลาส dash/pop/grow ผูกกับ IntersectionObserver ใน site.js"""

W = 'var(--warm)'
WL = 'var(--warm-lo)'
INK = 'var(--ink)'
DIM = 'rgba(255,255,255,.34)'
FAINT = 'rgba(255,255,255,.13)'
PANEL = '#161B24'


def _svg(vb, body, extra=''):
    return f'<svg viewBox="{vb}" fill="none" xmlns="http://www.w3.org/2000/svg" ' \
           f'aria-hidden="true" {extra}>{body}</svg>'


# ── 1 · ถาม–ตอบ: โทรศัพท์กับบทสนทนา ────────────────────────────────
def chat():
    body = f'''
<defs>
  <linearGradient id="ph" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#1B212C"/><stop offset="1" stop-color="#0C0F15"/>
  </linearGradient>
</defs>
<rect x="112" y="18" width="176" height="284" rx="30" fill="url(#ph)" stroke="{FAINT}"/>
<rect x="122" y="28" width="156" height="264" rx="22" fill="#0A0D12"/>
<rect x="176" y="34" width="48" height="7" rx="3.5" fill="{FAINT}"/>

<!-- ฟองคำถามจากผู้ใช้ -->
<g class="pop pop-d1">
  <rect x="168" y="58" width="100" height="34" rx="14" fill="{W}" opacity=".92"/>
  <rect x="180" y="69" width="64" height="4.5" rx="2.25" fill="#25120A" opacity=".72"/>
  <rect x="180" y="79" width="42" height="4.5" rx="2.25" fill="#25120A" opacity=".5"/>
</g>
<!-- ฟองคำตอบ -->
<g class="pop pop-d2">
  <rect x="132" y="102" width="126" height="58" rx="14" fill="{PANEL}" stroke="{FAINT}"/>
  <rect x="144" y="115" width="94" height="4.5" rx="2.25" fill="{DIM}"/>
  <rect x="144" y="127" width="78" height="4.5" rx="2.25" fill="{DIM}" opacity=".7"/>
  <rect x="144" y="139" width="56" height="4.5" rx="2.25" fill="{DIM}" opacity=".45"/>
</g>
<!-- การ์ดสาเหตุที่เป็นไปได้ -->
<g class="pop pop-d3">
  <rect x="132" y="172" width="126" height="66" rx="12" fill="#12161E" stroke="{FAINT}"/>
  <circle cx="147" cy="188" r="5" fill="{W}"/>
  <rect x="160" y="185" width="70" height="4.5" rx="2.25" fill="{DIM}"/>
  <circle cx="147" cy="206" r="5" fill="{W}" opacity=".55"/>
  <rect x="160" y="203" width="54" height="4.5" rx="2.25" fill="{DIM}" opacity=".6"/>
  <circle cx="147" cy="224" r="5" fill="{W}" opacity=".28"/>
  <rect x="160" y="221" width="62" height="4.5" rx="2.25" fill="{DIM}" opacity=".38"/>
</g>
<!-- ช่องพิมพ์ + ปุ่มคลื่นเสียง -->
<g class="pop pop-d4">
  <rect x="132" y="252" width="94" height="30" rx="15" fill="#12161E" stroke="{FAINT}"/>
  <rect x="144" y="265" width="46" height="4.5" rx="2.25" fill="{DIM}" opacity=".5"/>
  <circle cx="248" cy="267" r="15" fill="{W}"/>
  <g stroke="#25120A" stroke-width="2.2" stroke-linecap="round" class="wv">
    <path d="M242 263v8"/><path d="M248 259v16"/><path d="M254 264v6"/>
  </g>
</g>

<!-- คลื่นเสียงลอยด้านซ้าย -->
<g class="bars" stroke="{WL}" stroke-width="4" stroke-linecap="round" opacity=".85">
  <path d="M34 168v-26"/><path d="M50 176v-42"/><path d="M66 162v-14"/>
  <path d="M82 180v-50"/>
</g>
<text x="34" y="212" fill="{DIM}" font-size="11" font-family="ui-sans-serif,system-ui">
  <tspan>0:07</tspan></text>
'''
    return _svg('0 0 400 320', body, 'class="art-chat"')


# ── 2 · จำที่จอด ─────────────────────────────────────────────────
def parking():
    body = f'''
<rect x="14" y="14" width="372" height="252" rx="16" fill="#0C1016" stroke="{FAINT}"/>
<g stroke="{FAINT}" stroke-width="1">
  <path d="M14 78h372M14 142h372M14 206h372"/>
  <path d="M110 14v252M206 14v252M302 14v252"/>
</g>
<!-- ถนนเส้นหลัก -->
<path d="M14 142h372" stroke="rgba(255,255,255,.1)" stroke-width="16"/>
<path class="dash" d="M30 142h340" stroke="{WL}" stroke-width="2" stroke-dasharray="14 12" opacity=".55"/>
<!-- อาคาร -->
<g fill="#121722" stroke="{FAINT}">
  <rect x="40" y="36" width="54" height="30" rx="6"/>
  <rect x="132" y="30" width="42" height="36" rx="6"/>
  <rect x="238" y="40" width="66" height="26" rx="6"/>
  <rect x="60" y="184" width="60" height="34" rx="6"/>
  <rect x="240" y="180" width="80" height="40" rx="6"/>
</g>
<!-- คลื่นกระเพื่อมรอบหมุด -->
<g class="ripple">
  <circle cx="206" cy="176" r="16" fill="none" stroke="{W}" stroke-width="1.6"/>
  <circle cx="206" cy="176" r="16" fill="none" stroke="{W}" stroke-width="1.6"/>
</g>
<!-- หมุด -->
<g class="pop pop-d2">
  <path d="M206 140c-13 0-23 10-23 23 0 16 23 39 23 39s23-23 23-39c0-13-10-23-23-23z"
        fill="{W}"/>
  <circle cx="206" cy="163" r="8" fill="#1A0B04"/>
</g>
<!-- การ์ดบันทึกอัตโนมัติ -->
<g class="pop pop-d3">
  <rect x="228" y="82" width="150" height="62" rx="12" fill="#151A24" stroke="{FAINT}"/>
  <circle cx="248" cy="104" r="7" fill="{W}"/><path d="M245 104l2.6 2.6 4.4-5" stroke="#1A0B04" stroke-width="1.8" stroke-linecap="round"/>
  <rect x="264" y="98" width="86" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="264" y="110" width="58" height="5" rx="2.5" fill="{DIM}" opacity=".55"/>
  <rect x="244" y="126" width="112" height="5" rx="2.5" fill="{DIM}" opacity=".3"/>
</g>
'''
    return _svg('0 0 400 280', body)


# ── 3 · ตรวจใบเสนอราคา ───────────────────────────────────────────
def quote():
    body = f'''
<g class="pop">
  <path d="M96 22h208a10 10 0 0110 10v226l-16-9-16 9-16-9-16 9-16-9-16 9-16-9-16 9-16-9-16 9-16-9-16 9-16-9-16 9V32a10 10 0 0110-10z"
        fill="#12161E" stroke="{FAINT}"/>
</g>
<rect x="118" y="46" width="96" height="7" rx="3.5" fill="{DIM}" class="pop pop-d1"/>
<rect x="118" y="62" width="60" height="5" rx="2.5" fill="{DIM}" opacity=".45" class="pop pop-d1"/>

<g class="pop pop-d2">
  <rect x="118" y="92" width="120" height="5.5" rx="2.75" fill="{DIM}" opacity=".7"/>
  <rect x="250" y="92" width="42" height="5.5" rx="2.75" fill="{DIM}" opacity=".7"/>
  <circle cx="300" cy="95" r="9" fill="rgba(120,220,150,.16)" stroke="rgba(120,220,150,.5)"/>
  <path d="M296 95l3 3 5-6" stroke="rgba(150,240,180,.95)" stroke-width="1.8" stroke-linecap="round"/>
</g>
<g class="pop pop-d3">
  <rect x="118" y="124" width="98" height="5.5" rx="2.75" fill="{DIM}" opacity=".7"/>
  <rect x="250" y="124" width="42" height="5.5" rx="2.75" fill="{DIM}" opacity=".7"/>
  <circle cx="300" cy="127" r="9" fill="rgba(232,112,58,.18)" stroke="{W}"/>
  <path d="M297 124l6 6M303 124l-6 6" stroke="{WL}" stroke-width="1.8" stroke-linecap="round"/>
</g>
<g class="pop pop-d4">
  <rect x="118" y="156" width="112" height="5.5" rx="2.75" fill="{DIM}" opacity=".7"/>
  <rect x="250" y="156" width="42" height="5.5" rx="2.75" fill="{DIM}" opacity=".7"/>
  <circle cx="300" cy="159" r="9" fill="rgba(120,220,150,.16)" stroke="rgba(120,220,150,.5)"/>
  <path d="M296 159l3 3 5-6" stroke="rgba(150,240,180,.95)" stroke-width="1.8" stroke-linecap="round"/>
</g>
<rect x="118" y="196" width="174" height="1" fill="{FAINT}"/>
<rect x="118" y="212" width="70" height="7" rx="3.5" fill="{INK}" opacity=".8" class="pop pop-d4"/>
<rect x="238" y="212" width="54" height="7" rx="3.5" fill="{W}" class="pop pop-d4"/>

<!-- เส้นสแกนวิ่งขึ้นลง -->
<g class="scan">
  <rect x="86" y="0" width="228" height="2" fill="{WL}" opacity=".9"/>
  <rect x="86" y="-26" width="228" height="26" fill="url(#sg)"/>
</g>
<defs><linearGradient id="sg" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="{W}" stop-opacity="0"/>
  <stop offset="1" stop-color="{W}" stop-opacity=".22"/>
</linearGradient></defs>
'''
    return _svg('0 0 400 290', body, 'class="art-quote"')


# ── 4 · ฟังเสียงรถ ───────────────────────────────────────────────
def listen():
    bars = ''
    import math
    n = 34
    for i in range(n):
        x = 30 + i * 10.2
        h = 12 + abs(math.sin(i * 0.55)) * 62 + (i % 3) * 6
        bars += (f'<rect x="{x:.1f}" y="{(140-h/2):.1f}" width="4.4" height="{h:.1f}" rx="2.2" '
                 f'fill="{W}" opacity="{0.32 + (i%5)*0.14:.2f}" style="--i:{i}"/>')
    body = f'''
<rect x="14" y="40" width="372" height="200" rx="18" fill="#0C1016" stroke="{FAINT}"/>
<g class="eq">{bars}</g>
<path d="M30 140h340" stroke="{FAINT}"/>
<g class="pop pop-d2">
  <rect x="122" y="252" width="156" height="40" rx="20" fill="{PANEL}" stroke="{FAINT}"/>
  <circle cx="148" cy="272" r="11" fill="{W}"/>
  <rect x="145" y="267" width="6" height="10" rx="3" fill="#1A0B04"/>
  <rect x="170" y="264" width="86" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="170" y="276" width="52" height="5" rx="2.5" fill="{DIM}" opacity=".5"/>
</g>
<g class="pop pop-d3">
  <rect x="252" y="60" width="118" height="52" rx="12" fill="#151A24" stroke="{FAINT}"/>
  <rect x="268" y="76" width="60" height="5" rx="2.5" fill="{WL}"/>
  <rect x="268" y="90" width="86" height="5" rx="2.5" fill="{DIM}" opacity=".55"/>
</g>
'''
    return _svg('0 0 400 300', body, 'class="art-listen"')


# ── 5 · วัดอาการสั่น ─────────────────────────────────────────────
def shake():
    body = f'''
<rect x="14" y="18" width="372" height="176" rx="16" fill="#0C1016" stroke="{FAINT}"/>
<g stroke="{FAINT}"><path d="M14 62h372M14 106h372M14 150h372"/></g>
<!-- เส้นกราฟสองเส้น: ล้อกับเครื่อง -->
<path class="dash" d="M28 106c18-40 30 34 46-2s26 44 44 8 28-52 44-16 26 40 44 6 28-46 44-10 26 34 44 4"
      stroke="{W}" stroke-width="2.6" stroke-linecap="round"/>
<path class="dash" d="M28 128c22-14 26 16 46 4s24 20 44 6 28-24 44-8 26 18 44 2 28-20 44-6 26 14 44 2"
      stroke="rgba(140,190,255,.6)" stroke-width="2" stroke-linecap="round" style="transition-delay:.25s"/>
<g class="pop pop-d3">
  <rect x="238" y="206" width="148" height="72" rx="12" fill="#151A24" stroke="{FAINT}"/>
  <circle cx="260" cy="230" r="7" fill="{W}"/>
  <rect x="276" y="226" width="92" height="5" rx="2.5" fill="{DIM}"/>
  <circle cx="260" cy="254" r="7" fill="rgba(140,190,255,.7)"/>
  <rect x="276" y="250" width="66" height="5" rx="2.5" fill="{DIM}" opacity=".55"/>
</g>
<!-- รถการ์ตูนกำลังสั่น -->
<g class="shakecar">
  <path d="M36 262c4-22 12-34 22-38h58c10 4 20 16 24 38z" fill="{PANEL}" stroke="{FAINT}"/>
  <path d="M46 250c3-14 8-20 14-22h48c7 2 13 9 16 22z" fill="#0C1016"/>
  <rect x="30" y="258" width="156" height="16" rx="8" fill="{PANEL}" stroke="{FAINT}"/>
  <circle cx="64" cy="276" r="13" fill="#0A0D12" stroke="{W}" stroke-width="2.4"/>
  <circle cx="152" cy="276" r="13" fill="#0A0D12" stroke="{FAINT}" stroke-width="2.4"/>
</g>
'''
    return _svg('0 0 400 300', body, 'class="art-shake"')


# ── 6 · เตือนก่อนหมดอายุ ─────────────────────────────────────────
def remind():
    body = f'''
<path d="M40 152h320" stroke="{FAINT}" stroke-width="2"/>
<path class="dash" d="M40 152h320" stroke="{W}" stroke-width="2"/>

<g class="pop pop-d1">
  <circle cx="96" cy="152" r="9" fill="#0A0D12" stroke="{W}" stroke-width="2.4"/>
  <text x="96" y="128" fill="{WL}" font-size="15" text-anchor="middle"
        font-family="ui-sans-serif,system-ui" font-weight="600">30</text>
  <text x="96" y="186" fill="{DIM}" font-size="11.5" text-anchor="middle"
        font-family="ui-sans-serif,system-ui" class="d-lbl"
        data-th="วันก่อน" data-en="days before">วันก่อน</text>
</g>
<g class="pop pop-d2">
  <circle cx="200" cy="152" r="9" fill="#0A0D12" stroke="{W}" stroke-width="2.4"/>
  <text x="200" y="128" fill="{WL}" font-size="15" text-anchor="middle"
        font-family="ui-sans-serif,system-ui" font-weight="600">7</text>
  <text x="200" y="186" fill="{DIM}" font-size="11.5" text-anchor="middle"
        font-family="ui-sans-serif,system-ui" class="d-lbl"
        data-th="วันก่อน" data-en="days before">วันก่อน</text>
</g>
<g class="pop pop-d3">
  <circle cx="304" cy="152" r="11" fill="{W}"/>
  <text x="304" y="128" fill="{INK}" font-size="15" text-anchor="middle"
        font-family="ui-sans-serif,system-ui" font-weight="700">1</text>
  <text x="304" y="188" fill="{WL}" font-size="11.5" text-anchor="middle"
        font-family="ui-sans-serif,system-ui" class="d-lbl"
        data-th="วันก่อน" data-en="days before">วันก่อน</text>
</g>
<!-- ธงวันหมดอายุ -->
<g class="pop pop-d4">
  <path d="M360 152v-52" stroke="{FAINT}" stroke-width="2"/>
  <path d="M360 100h34l-8 11 8 11h-34z" fill="{W}"/>
</g>
<!-- กระดิ่งสั่น -->
<g class="bell pop pop-d2">
  <path d="M74 58c0-13 10-23 22-23s22 10 22 23c0 20 6 25 9 30H65c3-5 9-10 9-30z"
        fill="{PANEL}" stroke="{W}" stroke-width="2.2" stroke-linejoin="round"/>
  <path d="M88 94a8 8 0 0016 0" stroke="{W}" stroke-width="2.2" stroke-linecap="round"/>
</g>
'''
    return _svg('0 0 400 220', body, 'class="art-remind"')


# ── 7 · สมุดประวัติรถ ────────────────────────────────────────────
def book():
    rows = ''
    for i, w in enumerate([132, 104, 148, 88]):
        y = 92 + i * 42
        rows += f'''<g class="pop pop-d{i+1}">
  <rect x="52" y="{y}" width="296" height="32" rx="10" fill="#12161E" stroke="{FAINT}"/>
  <circle cx="72" cy="{y+16}" r="6" fill="{W}" opacity="{1-0.2*i:.2f}"/>
  <rect x="88" y="{y+9}" width="{w}" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="88" y="{y+20}" width="{w*0.55:.0f}" height="4" rx="2" fill="{DIM}" opacity=".4"/>
  <rect x="292" y="{y+12}" width="42" height="6" rx="3" fill="{DIM}" opacity=".3"/>
</g>'''
    body = f'''
<rect x="28" y="24" width="344" height="252" rx="18" fill="#0C1016" stroke="{FAINT}"/>
<rect x="52" y="50" width="120" height="8" rx="4" fill="{INK}" opacity=".85"/>
<rect x="52" y="66" width="76" height="5" rx="2.5" fill="{DIM}" opacity=".45"/>
<rect x="266" y="48" width="82" height="26" rx="13" fill="rgba(232,112,58,.14)" stroke="{W}"/>
<rect x="280" y="58" width="54" height="6" rx="3" fill="{WL}"/>
{rows}
'''
    return _svg('0 0 400 300', body)


# ── 8 · Chat Flow: แท็บห้าใบ ─────────────────────────────────────
def flow():
    labels = [('สาเหตุ', True), ('รายงาน', False), ('เตรียมเข้าอู่', False),
              ('ที่มา', False), ('ไทม์ไลน์', False)]
    tabs = ''
    x = 40
    for i, (t, on) in enumerate(labels):
        w = 30 + len(t) * 8
        fill = W if on else '#151A24'
        txt = '#1A0B04' if on else DIM
        tabs += (f'<g class="pop pop-d{min(i+1,4)}">'
                 f'<rect x="{x}" y="38" width="{w}" height="30" rx="15" fill="{fill}" '
                 f'stroke="{"none" if on else FAINT}"/>'
                 f'<rect x="{x+12}" y="51" width="{w-24}" height="5" rx="2.5" fill="{txt}" opacity=".8"/>'
                 f'</g>')
        x += w + 9
    body = f'''
<rect x="20" y="20" width="360" height="240" rx="16" fill="#0C1016" stroke="{FAINT}"/>
{tabs}
<g class="pop pop-d4">
  <rect x="40" y="88" width="320" height="1" fill="{FAINT}"/>
  <circle cx="56" cy="116" r="7" fill="{W}"/>
  <rect x="74" y="106" width="180" height="6" rx="3" fill="{DIM}"/>
  <rect x="74" y="120" width="240" height="5" rx="2.5" fill="{DIM}" opacity=".45"/>
  <circle cx="56" cy="160" r="7" fill="{W}" opacity=".6"/>
  <rect x="74" y="150" width="146" height="6" rx="3" fill="{DIM}" opacity=".8"/>
  <rect x="74" y="164" width="214" height="5" rx="2.5" fill="{DIM}" opacity=".35"/>
  <circle cx="56" cy="204" r="7" fill="{W}" opacity=".3"/>
  <rect x="74" y="194" width="122" height="6" rx="3" fill="{DIM}" opacity=".55"/>
  <rect x="74" y="208" width="188" height="5" rx="2.5" fill="{DIM}" opacity=".25"/>
</g>
'''
    return _svg('0 0 400 280', body)


# ── 9 · สไตล์การพูดสี่แบบ ────────────────────────────────────────
def styles():
    body = f'''
<g class="pop">
  <rect x="24" y="30" width="164" height="66" rx="16" fill="{PANEL}" stroke="{FAINT}"/>
  <rect x="42" y="50" width="98" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="42" y="64" width="122" height="5" rx="2.5" fill="{DIM}" opacity=".55"/>
  <rect x="42" y="78" width="66" height="5" rx="2.5" fill="{DIM}" opacity=".3"/>
</g>
<g class="pop pop-d1">
  <rect x="212" y="46" width="164" height="52" rx="16" fill="rgba(232,112,58,.13)" stroke="{W}"/>
  <rect x="230" y="62" width="112" height="5" rx="2.5" fill="{WL}"/>
  <rect x="230" y="76" width="76" height="5" rx="2.5" fill="{WL}" opacity=".55"/>
</g>
<g class="pop pop-d2">
  <rect x="52" y="126" width="164" height="52" rx="16" fill="{PANEL}" stroke="{FAINT}"/>
  <rect x="70" y="142" width="86" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="70" y="156" width="120" height="5" rx="2.5" fill="{DIM}" opacity=".5"/>
</g>
<g class="pop pop-d3">
  <rect x="236" y="134" width="140" height="66" rx="16" fill="{PANEL}" stroke="{FAINT}"/>
  <rect x="254" y="152" width="74" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="254" y="166" width="102" height="5" rx="2.5" fill="{DIM}" opacity=".5"/>
  <rect x="254" y="180" width="56" height="5" rx="2.5" fill="{DIM}" opacity=".28"/>
</g>
<!-- ปุ่มเลือกสไตล์ -->
<g class="pop pop-d4">
  <rect x="24" y="216" width="86" height="30" rx="15" fill="{W}"/>
  <rect x="40" y="229" width="54" height="5" rx="2.5" fill="#1A0B04" opacity=".75"/>
  <rect x="120" y="216" width="86" height="30" rx="15" fill="#12161E" stroke="{FAINT}"/>
  <rect x="136" y="229" width="54" height="5" rx="2.5" fill="{DIM}" opacity=".6"/>
  <rect x="216" y="216" width="72" height="30" rx="15" fill="#12161E" stroke="{FAINT}"/>
  <rect x="230" y="229" width="44" height="5" rx="2.5" fill="{DIM}" opacity=".6"/>
  <rect x="298" y="216" width="78" height="30" rx="15" fill="#12161E" stroke="{FAINT}"/>
  <rect x="312" y="229" width="50" height="5" rx="2.5" fill="{DIM}" opacity=".6"/>
</g>
'''
    return _svg('0 0 400 270', body)


# ── 10 · โควตาที่นับตามการใช้จริง ────────────────────────────────
def quota():
    body = f'''
<rect x="28" y="42" width="344" height="120" rx="16" fill="#0C1016" stroke="{FAINT}"/>
<rect x="52" y="70" width="120" height="7" rx="3.5" fill="{INK}" opacity=".8"/>
<rect x="52" y="102" width="296" height="14" rx="7" fill="#161B24"/>
<g class="grow" style="transform-origin:52px 109px">
  <rect x="52" y="102" width="182" height="14" rx="7" fill="{W}"/>
</g>
<rect x="52" y="130" width="150" height="5" rx="2.5" fill="{DIM}" opacity=".5"/>
<!-- คำถามสั้น–ยาว ใช้ไม่เท่ากัน -->
<g class="pop pop-d2">
  <rect x="28" y="190" width="164" height="58" rx="14" fill="{PANEL}" stroke="{FAINT}"/>
  <rect x="46" y="206" width="60" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="46" y="222" width="34" height="10" rx="5" fill="{W}" opacity=".55"/>
</g>
<g class="pop pop-d3">
  <rect x="208" y="190" width="164" height="58" rx="14" fill="{PANEL}" stroke="{FAINT}"/>
  <rect x="226" y="206" width="96" height="5" rx="2.5" fill="{DIM}"/>
  <rect x="226" y="222" width="106" height="10" rx="5" fill="{W}"/>
</g>
'''
    return _svg('0 0 400 270', body)


ALL = {
    'chat': chat, 'parking': parking, 'quote': quote, 'listen': listen,
    'shake': shake, 'remind': remind, 'book': book, 'flow': flow,
    'styles': styles, 'quota': quota,
}
